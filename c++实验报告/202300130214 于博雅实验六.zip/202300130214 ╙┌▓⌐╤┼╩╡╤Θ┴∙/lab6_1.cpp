#include <iostream>
using namespace std;
class Animal
{
	 
public:
	int age;
	Animal(int a=0):age(a)
	{
		
	}	
	~Animal()
	{
		
	}
	void setage(int a=3)
	{
		a=age;
	}
	int getage() 
	{
		return age;
	}
};

class dog:public Animal
{
	public:
	dog()
	{
		
	}	
	~dog()
	{
		
	}
	void setAge(int a)
	{
		age=a;
	}
	int getAge()
	{
		return age;
	}
};

int main()
{

	
	dog dog1;
	dog1.setAge(4);
	int p=dog1.getAge(); 
	cout<<p;	
	return 0;
}
