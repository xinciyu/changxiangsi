#include <iostream>
using namespace std;
class vehicle
{
public:
	int maxspeed;
	int weight;
	void run()
	{
		cout<<"������"<<endl;	
	}
	void stop()
	{
		cout<<"��ֹͣ"<<endl; 
	}		
};
class bicycle: virtual public vehicle
{
public:
	int height;
};
class motorcar: virtual public vehicle
{
public:
	int seatnum;	
};
class motorcycle:public motorcar,public bicycle
{
public:
	void run()
	{
		cout<<"Ħ�г�����"<<endl;	
	}
	void stop()
	{
		cout<<"Ħ�г�ֹͣ"<<endl; 
	}	
};
int main ()
{
	motorcycle m;
	m.maxspeed=39;
	m.weight=100;
	m.run();
	m.stop();
	return 0;
}
	
	
	
	
	
	
	
	
