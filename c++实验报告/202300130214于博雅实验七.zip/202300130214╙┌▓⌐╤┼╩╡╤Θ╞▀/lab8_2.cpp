#include <iostream>
using namespace std;
class vehicle
{
public:
	int maxspeed;
	int weight;
	virtual void run()
	{
		cout<<"������"<<endl;	
	}
	virtual void stop()
	{
		cout<<"��ֹͣ"<<endl; 
	}		
};

class bicycle: virtual public vehicle
{
public:
	int height;
	virtual void run()
	{
		cout<<"���г�����"<<endl;	
	}
	virtual void stop()
	{
		cout<<"���г�ֹͣ"<<endl; 
	}
};

class motorcar: virtual public vehicle
{
public:
	int seatnum;
	virtual void run()
	{
		cout<<"��������"<<endl;	
	}
	virtual void stop()
	{
		cout<<"����ֹͣ"<<endl; 
	}	
};
class motorcycle:public motorcar,public bicycle
{
public:
	void run()
	{
		cout<<"Ħ�г�����"<<endl;	
	}
	void stop()
	{
		cout<<"Ħ�г�ֹͣ"<<endl; 
	}	
};
int main ()
{
	vehicle v;
	v.run();
	v.stop();
	
	bicycle b;
	b.run();
	b.stop();
	
	motorcar c;
	c.run();
	c.stop();
	
	motorcycle m;
	m.run();
	m.stop();
	return 0;
}

