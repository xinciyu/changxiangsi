#include <iostream>
using namespace std;
class point
{
private:
	int _x;
	int _y;
public:
	point(int x=0,int y=0):_x(x),_y(y) {};
	point &operator++()
	{
		_x++;
		_y++;
		return *this;
	}
	point operator++(int)
	{
		point old=*this;
		++(*this);
		return old;
	}
	point &operator--()
	{
		_x--;
		_y--;
		return *this;
	}
	point operator--(int)
	{
		point old=*this;
		--(*this);
		return old;
	}
	void show()const
	{
		cout<<"��ǰ������꣺"<<_x<<","<<_y<<endl;	
	}	
}; 


int main ()
{
	point p(5,2);
	p.show();
	(p++).show();
	(++p).show();
	(--p).show();
	(p--).show();
	return 0;
}
