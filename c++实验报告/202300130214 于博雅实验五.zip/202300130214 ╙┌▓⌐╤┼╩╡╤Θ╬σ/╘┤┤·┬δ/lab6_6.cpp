#include <iostream>
#include "employee.h"
using namespace std;
int main()
{
	Employee emp[5] = { {"hulan","henan","zhenzhou","474500"},{"lixin","hubei","wuhan","243100"},{"wenwen","shanghai","pudong","231133"},{"mengmeng","xinjiang","wulunuqi","214433"},{"yuli","hebei","hengshui","243311"}};
	for (int i = 0; i < 5; i++)
	{
		emp[i].display();
	}
	return 0;
}