/*#include <iostream>
using namespace std;
int main()
{
	char a[20] = { 0 };
	char b[20] = { 0 };
	char c[40] = { 0 };
	cin >> a >> b;
	int i = 0, j = 0, k = 0;
	while (a[i] != '\0')
		c[k++] = a[i++];
	while (b[j] != '\0')
		c[k++] = b[j++];
	cout << c;
	return 0;
}
*/