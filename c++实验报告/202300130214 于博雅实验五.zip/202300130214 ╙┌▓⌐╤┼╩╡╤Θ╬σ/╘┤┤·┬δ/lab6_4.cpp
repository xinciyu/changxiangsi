#include <iostream>
using namespace std;
int main()
{
	string a;
	string b;
	cin >> a >> b;
	string c = a + b;
	cout << c;
	return 0;

}