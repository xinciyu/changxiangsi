/*#include <iostream>
using namespace std;
void zhuanzhi(int a[3][3])
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << a[j][i] << " ";
		}
		cout << "\n";
	}
}

int main()
{
	int a[3][3] = { 0 };
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin>> a[i][j];
		}
	}
	zhuanzhi(a);
	return 0;
}*/