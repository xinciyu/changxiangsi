#include <iostream>
using namespace std;

void zhuanzhi(int**p)
{
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << p[j][i] << " ";
		}
		cout << "\n";
	}
}
int main()
{
	const int r = 3, l = 3;
	int** p = new int* [r];
	for (int i = 0; i < l; i++)
		p[i] = new int[l];

	for(int i = 0; i < 3;i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cin >>p[i][j];
		}
	}
	zhuanzhi(p);
	for (int i = 0; i++; i < r)
		delete[]p[i];
	delete[]p;
	return 0;
}



