/*#include <iostream>
#include "employee.h"
using namespace std;
int main()
{
	Employee people("lihua", "HeBei", "zhangjiajie", "474500");
	people.display();
	people.change_name("WangZhihua");
	people.display();
	return 0;

}*/