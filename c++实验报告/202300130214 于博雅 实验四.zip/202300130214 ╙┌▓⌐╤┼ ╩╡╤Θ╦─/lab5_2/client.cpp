#include <iostream>
#include <string>
#include "client.h"
char CLIENT::servername[] = "lihua";
int CLIENT::clientnum = 19;
//���г�ʼ��
void CLIENT::changeservername(const char* newname)
{
	if (newname != nullptr)
	{
		strncpy_s(servername, newname, sizeof(servername) - 1);
		servername[sizeof(servername) - 1] = '\0';
	}
}
const char* CLIENT::getservername()
{
	return servername;
}
int CLIENT::getClientNumber(int clientnum)
{
	clientnum++;
	return clientnum;
}