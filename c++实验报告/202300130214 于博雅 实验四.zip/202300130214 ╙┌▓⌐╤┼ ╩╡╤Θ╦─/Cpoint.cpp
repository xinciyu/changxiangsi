#include <iostream>
#include <math.h>
using namespace std;
class CPoint
{
private:
    double x;  // ������  
    double y;  // ������  
public:
    CPoint(double xx = 0, double yy = 0) :x(xx), y(yy) {}
    double getX() const { return x; }
    double getY() const { return y; }
    void setX(double xx) { x = xx; }
    void setY(double yy) { y = yy; }
    double length1(CPoint&);
    friend double length2(CPoint&, CPoint&);

};
double CPoint::length1(CPoint&p)
{
    return sqrt(pow(p.x - x, 2) + pow(p.y - y, 2));
}
double length2(CPoint&p1, CPoint&p2)
{
    return sqrt(pow(p1.x - p2.x, 2) + pow(p1.y - p2.y, 2));
}
double length3(CPoint& p1, CPoint& p2)
{
    double x1 = p1.getX();
    double y1 = p1.getY();
    double x2 = p2.getX();
    double y2 = p2.getY();
    return sqrt(pow(x1 - x2, 2) + pow(y1 - y2, 2));
}
int main()
{
    CPoint p1(3, 5), p2(2, 8);
    double length = 0;
    length = p1.length1(p2);
    cout << "�����ǣ�" << length << endl;
    length = length2(p1, p2);
    cout << "�����ǣ�" << length << endl;
    length = length3(p1, p2);
    cout << "�����ǣ�" << length << endl;
    return 0;
}