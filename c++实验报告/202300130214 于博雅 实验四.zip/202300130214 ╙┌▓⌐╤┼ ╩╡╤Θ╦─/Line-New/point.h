#ifndef POINT_H
#define POINT_H
#include <iostream>
using namespace std;

class Point //Point������
{	
public:
    Point(int xx,int yy);
    Point(Point&);
    int getX();
    int getY();
private:
    int x, y;
};
#endif