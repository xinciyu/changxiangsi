#include <iostream>
using namespace std;
int main()
{
	int i = 100;
	int sum = 0;
	do {
		sum += i;
		i--;
	} while (i != 0);
	cout << "sum=" << sum << endl;
	return 0;
}