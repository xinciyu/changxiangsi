#include <iostream>
using namespace std;
int main()
{
	char ch;
	float a, b,c=0;
	cin >> a >> b >> ch;
	switch (ch)
	{
	case'+':c = a + b;
		cout <<a<<'+'<<b<<'='<<c<<endl;
		break;
	case'-':c = a - b;
		cout << a << '-' << b << '=' << c << endl;
		break;
	case'*':c = a * b;
		cout << a << '*' << b << '=' << c << endl;
		break;
	case'/':
		if (b == 0)
			cout << "��������Ϊ��";
		else
		{
			c = a / b;
			cout << a << '/' << b << '=' << c << endl;
		}
		break;
	}
	return 0;

}