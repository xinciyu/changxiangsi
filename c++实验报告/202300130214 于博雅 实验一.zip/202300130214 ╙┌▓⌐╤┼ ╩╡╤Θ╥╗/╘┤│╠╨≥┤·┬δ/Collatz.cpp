#include <iostream>
using namespace std;
int main()
{
	int n;
	int t = 0;
	cin >> n;
	while (n != 1)
	{
		if (n % 2 == 0){
			t = n / 2;
			cout << n << " / 2 = " << t << endl;
		}
		else{
			t = 3 * n + 1;
			cout << n << "*3+1=" << t << endl;
		}
		n = t;
	}
	cout << "End" << endl;
	return 0;
}