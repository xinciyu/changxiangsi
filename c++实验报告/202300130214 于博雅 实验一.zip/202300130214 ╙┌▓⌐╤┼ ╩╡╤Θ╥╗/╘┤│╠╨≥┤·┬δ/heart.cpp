#include<iostream>
#include<cmath>
using namespace std;
int main() {
    float y=1.5;
    while (y > -1.5)
    {
        float x = -1.5;
        while(x <= 1.5)
        {
            if((pow(x * x + y * y - 1.0, 3) - x * x * y * y * y) <=0.0)
            cout << '*';
            else
            cout << ' ';
            x =x+0.05;
        }
        y =y-0.1;
        cout << endl;
    }
    return 0;
}