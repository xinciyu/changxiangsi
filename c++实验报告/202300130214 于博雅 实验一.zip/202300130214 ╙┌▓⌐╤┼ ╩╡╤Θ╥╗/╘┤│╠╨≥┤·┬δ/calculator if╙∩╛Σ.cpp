#include <iostream>
using namespace std;
int main()
{
	float final = 0;
	float i1, i2;
	char cal;
	cin >> i1 >> i2 >> cal;
	if (cal == '+')
	{
		final = i1 + i2;
		cout << i1 << "+" << i2 << "=" << final;
	}
	if (cal == '-')
	{
		final = i1 - i2;
		cout << i1 << "-" << i2 << "=" << final;
	}
	if (cal == '*')
	{
		final = i1 * i2;
		cout << i1 << "*" << i2 << "=" << final;
	}
	if (cal == '/')
	{
		if (i2 == 0)
			cout << "��������Ϊ��" << endl;
		else
		{
			final = i1 + i2;
			cout << i1 << "/" << i2 << "=" << final;

		}
	}
	return 0;
}