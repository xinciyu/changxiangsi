#include <iostream>
using namespace std;
int main()
{
	char a[100] = {0};
	cin >> a;
	int j = 0;
	for (int i = 0; i < 100; i++)
	{
		if (a[i] != '\0')
			j++;
	}
	for (int t = j - 1; t >= 0; t--)
	{
		cout << a[t];
	}
	return 0;

}