#include <iostream>
using namespace std;
int f(int x)
{
	if (x > 0)
		return 1;
	if (x < 0)
		return -1;
	if (x == 0)
		return 0;
}
int main()
{
	int n;
	cin >> n;
	int a[10] = { 0 };
	int l = 0,num=0;
	for (int i = 0; i < n; i++)
		cin >> a[i];
	
	for (int i = 0; i < n; i++)
	{
		if (f(a[i]) == 1)
		{
			l++;
			num += a[i];
		}
	}
	double average = num *1.0/ l;
	cout << average;
	return 0;
}