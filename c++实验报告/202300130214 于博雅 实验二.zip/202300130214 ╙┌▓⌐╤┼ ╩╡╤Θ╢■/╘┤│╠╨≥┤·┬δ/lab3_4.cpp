/*#include <iostream>
#include <math.h>
using namespace std;
int main()
{
	float x, y;
	cin >> x >> y;
	float a = pow(x, y);
	cout << a << endl;
	return 0;
}*/
