#include <iostream>
using namespace std;
int judge(int x)
{
	for (int i = 2; i <= x / 2; i++)
	{
		if (x % i == 0)
			return 0;
	}
	return 1;
}
int main()
{
	int p=0;
	double F= 0, num = 0;
	int m, n;
	cin >> m >> n;
	for (int i = m; i <= n; i++)
	{
		p = judge(i);
		if (p == 1)
		{
			F = sqrt(i);
			num += F;
		}
	}
	cout << num;
	return 0;
}