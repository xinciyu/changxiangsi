/*#include <iostream>
using namespace std;
int maxl(int a, int b)
{
	if (a > b)
		return a;
	else
		return b;
}
int maxl(int a, int b, int x)
{

	int c=0;
	if (a > b)
		c= a;
	else
		c= b;
	if (x > c)
		return x;
	else
		return c;
}
double maxl(double a, double b)
{
	if (a > b)
		return a;
	else
		return b;
}
double maxl(double a, double b, double x)
{
	double c=0;
	if (a > b)
		c = a;
	else
		c = b;
	if (x > c)
		return x;
	else
		return c;
}
int main()
{
	int x1, x2, x3;
	double x4, x5, x6;
	cin >> x1 >> x2 >> x3 >> x4 >> x5 >> x6;
	int c1 = maxl(x1, x2);
	int c2 = maxl(x1, x2, x3);
	double c3 = maxl(x4, x5);
	double c4 = maxl(x4, x5, x6);
	cout << c1  << endl;
	cout << c2  << endl;
	cout << c3  << endl;
	cout << c4	<< endl;
	return 0;
}*/