/*#include <iostream>
using namespace std;
double change(double c)
{
	return (c - 32) * 5 / 9;;
}
int main()
{
	double C,F;
	cin >> C;
	F = change(C);
	cout << F << endl;
	return 0;
}*/